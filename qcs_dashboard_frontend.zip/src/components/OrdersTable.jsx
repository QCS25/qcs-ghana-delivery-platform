import React from "react";

export default function OrdersTable({ orders }) {
  return (
    <div className="bg-white p-4 rounded shadow">
      <h2 className="text-lg font-semibold mb-2">Recent Orders</h2>
      <table className="w-full text-sm">
        <thead className="bg-slate-100">
          <tr>
            <th className="p-2 text-left">Order ID</th>
            <th className="p-2 text-left">Customer</th>
            <th className="p-2 text-left">Status</th>
            <th className="p-2 text-left">Created</th>
          </tr>
        </thead>
        <tbody>
          {orders.length===0 && (
            <tr>
              <td className="p-2" colSpan="4">No recent orders</td>
            </tr>
          )}
          {orders.map(o=>(
            <tr key={o.id} className="border-t">
              <td className="p-2">{o.id}</td>
              <td className="p-2">{o.customer}</td>
              <td className="p-2">{o.status}</td>
              <td className="p-2">{new Date(o.date).toLocaleString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
