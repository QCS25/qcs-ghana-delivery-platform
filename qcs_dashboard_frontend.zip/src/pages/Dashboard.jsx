import React from "react";
import { useQuery } from "react-query";
import { fetchDashboard } from "../services/api";
import StatCard from "../components/StatCard";
import OrdersTable from "../components/OrdersTable";

export default function Dashboard() {
  const { data, isLoading, isError, error } = useQuery("dashboard", fetchDashboard, {
    retry: 1,
    refetchOnWindowFocus: false
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <div className="loader mb-4" />
          <p className="text-gray-500">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="p-6">
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <div className="mt-4 text-red-600">Error loading dashboard: {error.message}</div>
      </div>
    );
  }

  const stats = data.stats || {};
  const orders = data.recentOrders || [];

  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <header className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-[#002B5C]">QCS Admin Dashboard</h1>
        <div>
          <button className="px-3 py-1 bg-orange-500 text-white rounded" onClick={()=>{
            localStorage.removeItem("qcs_token");
            window.location.href="/login";
          }}>Logout</button>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <StatCard title="Total Orders" value={stats.totalOrders || 0} />
        <StatCard title="Pending" value={stats.pending || 0} />
        <StatCard title="Completed" value={stats.completed || 0} />
        <StatCard title="Revenue (GHS)" value={stats.revenue || 0} />
      </div>

      <div className="mt-6">
        <OrdersTable orders={orders} />
      </div>
    </div>
  );
}
