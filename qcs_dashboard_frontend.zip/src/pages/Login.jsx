import React, { useState } from "react";

export default function Login() {
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [err, setErr] = useState("");

  const submit = async (e) => {
    e.preventDefault();
    // Mock login for prototype
    if (!email) {
      setErr("Enter email");
      return;
    }
    localStorage.setItem("qcs_token", "demo-token");
    window.location.href = "/";
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
      <div className="max-w-md w-full bg-white p-6 rounded-md shadow">
        <h2 className="text-2xl font-bold mb-4 text-[#002B5C]">QCS Admin Login</h2>
        <form onSubmit={submit} className="space-y-4">
          <div>
            <label className="block text-sm">Email</label>
            <input value={email} onChange={e=>setEmail(e.target.value)} className="w-full border p-2 rounded"/>
          </div>
          <div>
            <label className="block text-sm">Password</label>
            <input value={pass} onChange={e=>setPass(e.target.value)} type="password" className="w-full border p-2 rounded"/>
          </div>
          {err && <div className="text-red-500">{err}</div>}
          <button className="w-full bg-[#002B5C] text-white p-2 rounded">Sign in</button>
        </form>
      </div>
    </div>
  );
}
