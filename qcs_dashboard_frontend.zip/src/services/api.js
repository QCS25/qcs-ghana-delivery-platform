import axios from "axios";

const API_BASE = (import.meta.env.VITE_API_URL) || "https://example.com";

const client = axios.create({
  baseURL: API_BASE,
  timeout: 10000
});

client.interceptors.request.use((config)=>{
  const token = localStorage.getItem("qcs_token");
  if(token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

export async function fetchDashboard(){
  // Example: in production this should hit your backend
  try {
    const res = await client.get("/api/dashboard");
    return res.data;
  } catch (err) {
    // For demo, return mock data if endpoint fails
    if(err.response === undefined){
      return {
        stats: {
          totalOrders: 120,
          pending: 8,
          completed: 110,
          revenue: 4520
        },
        recentOrders: [
          {id: "ORD-1001", customer: "John Doe", status: "Delivered", date: new Date().toISOString()},
          {id: "ORD-1002", customer: "Mary Smith", status: "Pending", date: new Date().toISOString()}
        ]
      };
    }
    throw err;
  }
}
