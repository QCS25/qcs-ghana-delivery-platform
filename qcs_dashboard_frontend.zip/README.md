# QCS Admin Dashboard (Prototype)

This is a Vite + React + Tailwind prototype for the QCS Admin Dashboard.
It includes a working dashboard that fetches from `/api/dashboard`. If the API is unavailable,
the frontend returns mock demo data so the UI won't spin indefinitely.

## Quick start

1. Install dependencies:
   npm install

2. Run dev server:
   npm run dev

3. Set the API url in `.env`:
   VITE_API_URL=https://your-backend.com
